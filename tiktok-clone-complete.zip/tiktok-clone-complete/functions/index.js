const functions = require("firebase-functions");
const admin = require("firebase-admin");
const spawn = require("child-process-promise").spawn;
const path = require("path");
const os = require("os");
const fs = require("fs");

admin.initializeApp();

exports.generateThumbnail = functions.storage.object().onFinalize(async (object) => {
  // Solo procesar objetos subidos dentro de la carpeta videos/
  if (!object.name || !object.name.startsWith("videos/")) return null;

  const filePath = object.name;
  const fileBucket = object.bucket;
  const bucket = admin.storage().bucket(fileBucket);

  const tempFilePath = path.join(os.tmpdir(), "video.mp4");
  const tempThumbPath = path.join(os.tmpdir(), "thumb.jpg");

  // Descarga el archivo
  await bucket.file(filePath).download({ destination: tempFilePath });

  // Ejecuta ffmpeg para extraer thumbnail (1s)
  await spawn("ffmpeg", [
    "-i", tempFilePath,
    "-ss", "00:00:01",
    "-vframes", "1",
    tempThumbPath
  ]);

  const thumbPath = filePath.replace("videos/", "thumbnails/").replace(/\.mp4$/i, ".jpg");

  // Sube el thumbnail
  await bucket.upload(tempThumbPath, { destination: thumbPath });

  // Limpia temporales
  fs.unlinkSync(tempFilePath);
  fs.unlinkSync(tempThumbPath);

  console.log("Thumbnail creado en:", thumbPath);
  return null;
});
